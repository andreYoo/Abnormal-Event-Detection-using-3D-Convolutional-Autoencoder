__author__ = 'jongminyu'
from apiclient.discovery import build
from apiclient.errors import HttpError
from oauth2client.tools import argparser
import json
from urlparse import urlparse
import urllib
import urllib2
import pafy

import os
import sys

DEVELOPER_KEY = "AIzaSyDNOYQVbMX6Y785KQSsgxGFc2aXWsSC0CE"
YOUTUBE_API_SERVICE_NAME = "youtube"
YOUTUBE_API_VERSION = "v3"
base_url = "https://www.youtube.com/watch?v="

def input_parser(input_string):
    """
    parsing function for input string
    single string = there is one keyword in user input
    multi string = there exist more then one keyword in user input
    :param intput: input string (single keyword or multi keyword)
    :return: list of keyword
    """
    #input_list = input_string.split(',')
    input_list = input_string.split('\n')
    return input_list

def step_saver(fileadd, skey,steps):
    fileadd.write(skey+'\t'+ str(steps))

def step_load(fileadd):
    step_data = fileadd.read()
    temp = step_data.split('\t')
    skey = temp[0]
    steps = int(temp[1])
    return skey,steps

def download_thumbnail_image(url,title="default"):
    """
    :param url: address of thumbnail image
    :param title: string of saved file title
    :return:
        Ture : download is finish
        False : download is false
    """
    image = urllib.URLopener()
    image.retrieve(url,title)


def youtube_search(options,size_dataset = 100):
    youtube = build(YOUTUBE_API_SERVICE_NAME, YOUTUBE_API_VERSION,
        developerKey=DEVELOPER_KEY)

  # Call the search.list method to retrieve results matching the specified
  # query term.
    next_page_token = ''
    search_response = youtube.search().list(
        q=options.q,
        part="id,snippet",
        maxResults=options.max_results,
        pageToken = next_page_token
    ).execute()
    videos = []
    url_list = []
    url_list.append([])
    url_list.append([])

    while True:
        for search_result in search_response.get("items", []):
            if search_result["id"]["kind"] == "youtube#video":
                videos.append("%s(Thumbnail image: %s) (url : %s)" % (search_result["snippet"]["title"],search_result["snippet"]["thumbnails"]["default"]["url"],base_url+search_result["id"]["videoId"]))
                url_list[0].append("%s"%(search_result["snippet"]["thumbnails"]["default"]["url"]))
                url_list[1].append("%s"%(base_url+search_result["id"]["videoId"]))
        #print "Videos:\n", "\n".join(videos), "\n"

        next_page_token = search_response.get("nextPageToken") #get a next page information from current research results
        #condition for expriment
        if len(url_list[0]) > size_dataset:
            break

        if next_page_token=='':
            break
        else:
            search_response = youtube.search().list(
                q=options.q,
                part="id,snippet",
                maxResults=options.max_results,
                pageToken = next_page_token
            ).execute()
    return url_list

def get_video_list(keyword,step):
    """
    :param keyword: query for video searching
    :param npk: next_page_token
    :return:
    """
    input_query = keyword
    list_length = 50
    next_page_token = "nextPageToken"
    if step ==0 :
        argparser.add_argument("--q", help="Search term", default=input_query)
        argparser.add_argument("--max-results", help="Max results", default=list_length)
        argparser.add_argument("--pageToken",help="Nextpage", default = next_page_token)
    else:
        argparser.set_defaults(q=input_query)
        argparser.set_defaults(max_result=list_length)
        argparser.set_defaults(pageToken = next_page_token)
    args = argparser.parse_args()
    try:
        print "Searching.....\n"
        url_list = youtube_search(args,100) # url_list;this list includes addresses of thumbnail image and video
        print "fin\n"
    except HttpError, e:
        print "An HTTP error %d occurred:\n%s" % (e.resp.status, e.content)
    del args
    return url_list

def classification_module(url_list):
    """
    :param url_list: thumbnail image address + youtube video address
    :return:
    image anlaysis and classification module for video download
    """
    #thumbnail image download

    #image analysis (using deep learning)

    #re-construction of list by considering classification results

    classified_list = []
    return classified_list

def download_module(url_list,file_path ="./DB_YOUTUBE/",keyword="default",filepath='ctrl.txt',list_step=0):
    directory = file_path+keyword
    if not os.path.exists(directory):
        os.makedirs(directory)
    path = directory+'/'
    step_count = list_step



    for addr in url_list:
        ctrfile = open(filepath,'r+')
        ctrfile.write(keyword+'\t'+str(step_count))
        video = pafy.new(addr)
        title = video.title
        best = video.getbest(preftype="mp4")
        best.download(filepath = path+str(step_count)+'.mp4')
        step_count += 1
        ctrfile.close()



