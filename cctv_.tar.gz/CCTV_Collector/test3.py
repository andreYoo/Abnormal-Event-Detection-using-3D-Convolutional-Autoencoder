__author__ = 'jongminyu'

from test2 import YoutubeAPI
import test2

youtube = YoutubeAPI('key':"AIzaSyDNOYQVbMX6Y785KQSsgxGFc2aXWsSC0CE")
video = youtube.get_video_info('rie-hPVJ7Sw')
results = youtube.search('Android')


video_list = youtube.search_videos('Android')

video_list = youtube.search_channel_videos('keyword', 'UCk1SpWNzOs4MYmr0uICEntg', 50)



channel = youtube.get_channel_by_name('xdadevelopers')

channel = youtube.get_channel_by_id('UCk1SpWNzOs4MYmr0uICEntg')

playlist = youtube.get_playlist_by_id('PL590L5WQmH8fJ54F369BLDSqIwcs-TCfs')


playlist_items = youtube.get_playlist_items_by_playlist_id('PL590L5WQmH8fJ54F369BLDSqIwcs-TCfs')

activities = youtube.get_activities_by_channel_id('UCk1SpWNzOs4MYmr0uICEntg')

video_id = youtube.parse_vid_from_url('https://www.youtube.com/watch?v=moSFlvxnbgk')