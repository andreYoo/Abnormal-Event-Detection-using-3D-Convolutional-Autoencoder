__author__ = 'jongminyu'

import httplib
import os
import sys
import urllib.request
import urllib.parse
import re

query_string = urllib.parse.urlencode()
html_content = urllib.request.urlopen()
search_reults = re.findall()
print()