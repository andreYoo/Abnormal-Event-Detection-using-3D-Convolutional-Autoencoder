__author__ = 'jongminyu'

import pafy
import numpy

import sys
import os
import modules


def demo():
    #input string
    #raw_input = input()
    kf_path = 'kfile2.txt'
    cf_path = 'ctrl.txt'
    key_keyword = ['CCTV','surveillance video']
    controlfile = open(cf_path,'r+')
    keyfile = open(kf_path,'r')
    raw_input = keyfile.read() #Temporal input
    #parse input string
    query_list = modules.input_parser(raw_input)
    npk = "nextPageToken"
    url_list = []
    list_dim = 0
    switch_on = 0

    p_skey, step = modules.step_load(controlfile)
    if p_skey!='0':
        switch_on = 1;
    for skey in query_list:
	# if step_load 
 	# else
        #get youtube links
        if switch_on==1:
            if skey==p_skey:
                print 'keyword : '+p_skey+'list_step : '+str(step)
                switch_on=0;
                url_list.append([])
                url_list[list_dim] = modules.get_video_list(skey,list_dim)
                download_list = url_list[list_dim][1]
                list_dim += 1
                modules.download_module(download_list[step+1:len(download_list)-1],keyword=skey,filepath='ctrl.txt',list_step=step)
            else:
                print 'skip keyword'+skey
                continue
        else:
            print 'Fist downloading is start'
            url_list.append([])
            url_list[list_dim] = modules.get_video_list(skey,list_dim)
            download_list = url_list[list_dim][1]
            list_dim += 1
            #download tumbnails
            #download_list = modules.classification_module(url_list,skey)
            #clasification using downloaded image
            #download_list = modules.classification_module(download_list)
            #download video
            modules.download_module(download_list,keyword=skey,filepath='ctrl.txt')

    return 0

if __name__ == "__main__":
    fin_path = 'fin.txt'
    fkfile = open(fin_path,'r+')
    fin_key = fkfile.read()
    if fin_key=='1':
	print 'Crawling is finish\n'
    demo()
    fkfile.write('1')
    fkfile.close()


