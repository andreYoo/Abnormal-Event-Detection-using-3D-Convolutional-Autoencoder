#!/bin/bash
# Trains a feed forward net on MNIST.
python main.py
