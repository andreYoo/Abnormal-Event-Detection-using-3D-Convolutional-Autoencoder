__author__ = 'jongminyu'

"""
System flow of video collctor

(1) input query to youtube
(2) get estimated video list
(3) get url list
(4) obtain initial n frame from url list :(thumnail image)
(5) image classification or video classification
(6) download full video from classified url

"""

from apiclient.discovery import build
from apiclient.errors import HttpError
from oauth2client.tools import argparser
import json
from urlparse import urlparse
import urllib
import urllib2
import pafy

# Set DEVELOPER_KEY to the API key value from the APIs & auth > Registered apps
# tab of
#   https://cloud.google.com/console
# Please ensure that you have enabled the YouTube Data API for your project.
DEVELOPER_KEY = "AIzaSyDNOYQVbMX6Y785KQSsgxGFc2aXWsSC0CE"
YOUTUBE_API_SERVICE_NAME = "youtube"
YOUTUBE_API_VERSION = "v3"
base_url = "https://www.youtube.com/watch?v="

def download_thumbnail_image(url,title="default"):
  image = urllib.URLopener()
  image.retrieve(url,title)

def youtube_search(options):
  youtube = build(YOUTUBE_API_SERVICE_NAME, YOUTUBE_API_VERSION,
    developerKey=DEVELOPER_KEY)

  # Call the search.list method to retrieve results matching the specified
  # query term.
  next_page_token = ''
  search_response = youtube.search().list(
    q=options.q,
    part="id,snippet",
    maxResults=options.max_results,
    pageToken = next_page_token
  ).execute()
  videos = []

  for search_result in search_response.get("items", []):
    if search_result["id"]["kind"] == "youtube#video":
      videos.append("%s(Thumbnail image: %s) (url : %s)" % (search_result["snippet"]["title"],search_result["snippet"]["thumbnails"]["default"]["url"],base_url+search_result["id"]["videoId"]))

  print "Videos:\n", "\n".join(videos), "\n"

  next_page_token = search_response.get("nextPageToken") #get a next page information from current research results
  
  search_response = youtube.search().list(
    q=options.q,
    part="id,snippet",
    maxResults=options.max_results,
    pageToken = next_page_token
  ).execute()
  videos = []

  for search_result in search_response.get("items", []):
    if search_result["id"]["kind"] == "youtube#video":
      videos.append("%s(Thumbnail image: %s) (url : %s)" % (search_result["snippet"]["title"],search_result["snippet"]["thumbnails"]["default"]["url"],base_url+search_result["id"]["videoId"]))
      samplecode = base_url+search_result["id"]["videoId"]
      sample_address = search_result["snippet"]["thumbnails"]["default"]["url"]
  print "Videos:\n", "\n".join(videos), "\n"
  return samplecode, sample_address


def demo(npk):
  input_query = "CCTV"
  list_length = 50
  next_page_token = npk
  argparser.add_argument("--q", help="Search term", default=input_query)
  argparser.add_argument("--max-results", help="Max results", default=list_length)
  argparser.add_argument("--pageToken",help="Nextpage", default = next_page_token)
  args = argparser.parse_args()

  try:
    print "Searching.....\n"
    sampel_code, sample_address = youtube_search(args)
    print "fin\n"
  except HttpError, e:
    print "An HTTP error %d occurred:\n%s" % (e.resp.status, e.content)

  return sampel_code, sample_address

if __name__ == "__main__":
  next_page_token = "nextPageToken"
  samplecode,sample_address = demo(next_page_token)
  video = pafy.new(samplecode)

  print video.title
  print video.rating

  download_thumbnail_image(sample_address,"test.png") # example of thumbnail image download.
  #modulization is needed.(today)

