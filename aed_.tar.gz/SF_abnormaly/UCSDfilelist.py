__author__ = 'schmizt'
import cv2
import video
import os

_experiment_path = '/media/Database/VISAPP_TESTDB/'
_GIST_path = 'GIST_DB/'
_UCSDPed_path = 'UCSDPed/'
_UCSDPed1_train_path = 'UCSDped1/Train/'
_UCSDPed1_test_path = 'UCSDped1/Test/'
_UCSDPed2_train_path = 'UCSDped2/Train/'
_UCSDPed2_test_path = 'UCSDped2/Test/'

def Get_UCSD_filelist(_dir_path):
    res2 = []
    res = []
    for root, dirs, files in os.walk(_dir_path):
        rootpath = os.path.join(os.path.abspath(_dir_path), root)
        for file in files:
            filepath = os.path.join(rootpath, file)
            res.append(filepath)
        res = []
        res2.append(res)
    return res2


def GET_GIST_filelist(_dir_path):
    res2 = []
    res = []
    for root, dirs, files in os.walk(_dir_path):
        rootpath = os.path.join(os.path.abspath(_dir_path), root)
        for file in files:
            filepath = os.path.join(rootpath, file)
            res.append(filepath)
        res = []
        res2.append(res)
    return res2

if __name__ == '__main__':
    _frame = 0
    #_filepath = _experiment_path+_UCSDPed_path+_UCSDPed1_train_path #UCSD Ped 1 training dataset file path
    _filepath = _experiment_path+_GIST_path
    #flist = Get_UCSD_filelist(_filepath)
    flist = GET_GIST_filelist(_filepath)
    for _fpath in flist:
        for _in in _fpath:
            _t1= _in.split('.')
            if _t1[1] =='tif':
                img = cv2.imread(_in)
                cv2.putText(img,str(_frame),(10,30),cv2.FONT_HERSHEY_COMPLEX_SMALL,1,(255,0,0))
                cv2.imshow(str(_fpath),img)
                cv2.waitKey(5)
                _frame +=1
        _frame = 0
        cv2.destroyAllWindows()
    print 'path done'