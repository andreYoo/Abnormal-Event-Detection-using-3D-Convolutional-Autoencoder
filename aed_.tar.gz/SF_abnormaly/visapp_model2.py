__author__ = 'jongminyu'

#!/usr/bin/env python

import numpy as np
import cv2
import video
import sys
from matplotlib import pyplot as plt
import math
import random


_message = '''
Keys:
    Title.Abnormal event detection
    Dev by J.m.Yu @ GIST & Ph.D Candidate
    Dev at 2015
    'esc' : exit process
    volume length is 10
'''

def draw_flow(img, flow, step=16):
    h, w = img.shape[:2]
    y, x = np.mgrid[step/2:h:step, step/2:w:step].reshape(2,-1)
    fx, fy = flow[y,x].T
    lines = np.vstack([x, y, x+fx, y+fy]).T.reshape(-1, 2, 2)
    lines = np.int32(lines + 0.5)
    vis = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    cv2.polylines(vis, lines, 0, (0, 255, 0))
    for (x1, y1), (x2, y2) in lines:
        cv2.circle(vis, (x1, y1), 1, (0, 255, 0), -1)
    return vis

def draw_grid(img,_window_size=10):
    h, w = img.shape[:2]
    vis = show_grid(cv2.cvtColor(img,cv2.COLOR_GRAY2BGR),_window_size)
    return vis


def show_grid(img,_window_size=10):
    _width,_height,_depth = np.shape(img)
    for i in range(_width/_window_size):
        img[i*_window_size,:,:] = 0
    for j in range(_height/_window_size):
        img[:,j*_window_size,:] = 0
    return img

def show_class_map(img,classmap,_windowsize):
    _width,_height,_depth = np.shape(img)
    maximum_value = classmap.max()
    color_map = np.zeros((maximum_value+2,3),dtype = int)
    for k in range(maximum_value+2):
        color_map[k,:] = ((np.random.rand(1,3))*1000)%255
    for i in range(_width/_windowsize):
        for j in range(_height/_windowsize):
                img[i*_windowsize:i*_windowsize+_windowsize,j*_windowsize:j*_windowsize+_windowsize,:] = color_map[classmap[i,j],:]
    return img


def draw_ra_result(img,_windowsize,classmap):
    vis = show_class_map(cv2.cvtColor(img,cv2.COLOR_GRAY2BGR),classmap,_windowsize)
    return vis

def draw_sf_flow(img, flow, step=16):
    h, w = img.shape[:2]
    y, x = np.mgrid[step/2:h:step, step/2:w:step].reshape(2,-1)
    fx, fy = flow[y,x].T
    lines = np.vstack([x, y, x+fx, y+fy]).T.reshape(-1, 2, 2)
    lines = np.int32(lines + 0.5)
    vis = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    cv2.polylines(vis, lines, 0, (0, 0, 255))
    for (x1, y1), (x2, y2) in lines:
        cv2.circle(vis, (x1, y1), 1, (0, 0, 255), -1)
    return vis

def show_magnitude_map(title,magnitude_flow):
    if title=='Optical flow magnitude':
        p = plt.imshow(magnitude_flow, interpolation="gaussian")
    elif title=='Social force magnitude':
        p = plt.imshow(magnitude_flow, interpolation="gaussian")
    else:
        print '[error] title parameter only can process two input (Optical flow magnitude and Social force magnitude)\n'
        sys.exit()

def calcSocialForceMeharn(avg_of,current_of,previous_of):
    '''
    :param avg_of: average optical flow of spatio-temporal volume
    :param current_of: optical flow at current steps
    :param previous_of: optical flow at previous steps
    :return: actual force (social force model)
    '''
    tau = 2.0
    panic = 1.0
    _temp = (1-panic)*current_of-panic*avg_of-current_of
    actual_force = 2/tau*(_temp)-(current_of-previous_of)
    return actual_force


def calcHistogram(wflow,B=8):
    '''
    :param wflow: object flow in specific window
    :param B: hisgotram size
    :return: histogram of object flow
    '''
    _interval = 360/B
    _bins = range(0,360,_interval)
    _bins.append(360)
    _width,_height,_depth = np.shape(wflow)
    _result = np.reshape(wflow,(_width*_height*_depth))
    _flow_histogram = np.histogram(wflow,bins=_bins)
    return _flow_histogram


def calcEntropyfromHistogram(_histogram):
    '''
    :param flow: flow element such as optical flow and social force model
    :return: entropy map of flow elements
    '''
    _total_histogram = sum(_histogram[0])
    _entropy = 0.0
    _length = len(_histogram[0])
    for i in range(_length):
        if _histogram[0][i] == 0:
            continue
        else:
            _entropy += (-1.0)*(float(_histogram[0][i])/float(_total_histogram))*math.log((float(_histogram[0][i])/float(_total_histogram)),10)
    return _entropy

def avg_speed_in_grid(grid_mag_map):
    '''
    Compute average speed in each grid using magnitude map
    :param grid_mag_map: each window extracted from magnitude map
    :param g_w: width size of grid (window)
    :param g_h: height size of grid (Window)
    :return: average speed of each window
    '''
    _width,_height = np.shape(grid_mag_map)
    avg_speed = 0.0
    '''
    for i in range(_width):
        for j in range(_height):
            avg_speed += grid_mag_map[i,j]
    '''
    avg_speed = sum(sum(grid_mag_map))
    return avg_speed/(_width*_height)

def avg_speed_in_volume(volume_mag_map):
    '''
    :param volume_mag_map: spatio-temporal voluem of magnitude map (sequence of magnitude map)
    :return: average speed that is represented by optical flow of spatio-temporal volume
    '''
    _width,_height,_length = np.shape(volume_mag_map)
    avg_speed = 0.0
    for l in range(_length):
        avg_speed += avg_speed_in_grid(volume_mag_map[:,:,l])
    return avg_speed/_length


def of_histogram_show(flow):
    return 0

def sf_histogram_show():
    return 0

def segmentation_by_of():
    return 0

def segmentation_by_sf():
    return 0


def speed_map():
    return 0

def _spatio_feature_map(set_mag_map,set_dvec_map,_gw,_gh):
    '''
    Version 1 spatial feature map
    :param set_mag_map:
    :param set_dvec_map:
    :return:
    '''
    _grid_width = _gw
    _grid_height = _gh
    _width, _height,_length = np.shape(set_mag_map)
    _feature_map = np.zeros((_width/_grid_height,_height/_grid_height,2),dtype=float)
    for i in range(_width/_grid_width):
        for j in range(_height/_grid_height):
            _feature_map[i,j,0] = avg_speed_in_volume(set_mag_map[i*10:i*10+10,j*10:j*10+10,:])
            _feature_map[i,j,1] = calcEntropyfromHistogram(calcHistogram(set_dvec_map[i*10:i*10+10,j*10:j*10+10,:],12))
    return _feature_map

def _spatiotemporal_feature_map(st_mag_map,st_dvec_map,_gw,_gh,_gd):# not work - will be modified
    '''
    version 1 spatio-temporal feature map
    We assume that temporal depth of input of this function is 10
    :param st_mag_map:
    :param st_dvec_map:
    :return:
    '''
    _volume_width = _gw
    _volume_height = _gh
    _volume_depth = _gd
    _width, _height,_depth = np.shape(set_mag_map)
    if _depth/_volume_depth==1:
        _feature_map = _spatio_feature_map(st_mag_map,st_dvec_map,_gw,_gh)
    else:
        _feature_map = np.zeros((_width/_volume_height,_height/_volume_height,2,_depth/_volume_depth),dtype=float)
        for i in range(_width/_volume_width):
            for j in range(_height/_volume_height):
                for k in range(_depth/_volume_depth):
                    _feature_map[i,j,0,k] = avg_speed_in_volume(set_mag_map[i*_volume_width:i*_volume_width+_volume_width,j*_volume_height:j*_volume_height+_volume_height,k*_volume_depth:k*_volume_depth+_volume_depth])
                    _feature_map[i,j,1,k] = calcEntropyfromHistogram(calcHistogram(set_dvec_map[i*_volume_width:i*_volume_width+_volume_width,j*_volume_height:j*_volume_height+_volume_height,k*_volume_depth:k*_volume_depth+_volume_depth],12))
    return _feature_map




def map_show(title,img,flow):
    '''
    :param title: window title
    :param img:original image
    :param flow: element flow
    :return:
    '''
    if title=='Optical flow':
        flow  *= 5 #emphasize optical flow for visualization
        cv2.imshow('Optical flow', draw_flow(img, flow))
    elif title=='Social force flow':
        flow *= 3
        cv2.imshow('Social force flow',draw_sf_flow(img,flow))
    else:
        print '[error] : '+title+'is not mapping element'
        return 0

def unit_vector(vector):
    '''
    making unit vector from input (vector)
    :param vector: input vector
    :return: unit vector from input vector
    '''
    return vector/np.linalg.norm(vector)



def dvector_flow(flow): #this function needs the most heavy computation resource
    '''
    :param flow: flow element such as optical flow and social force model
    :return: direction element (i.e. 30 degree)
    '''
    _width, _height, _depth = np.shape(flow)
    dvector_map = np.zeros((_width,_height),dtype=float)
    baseline_vector = [1.0,0.0]
    for i in range(_width):
        for j in range(_height):
            _vector =  unit_vector(flow[i,j,:])
            _temp = flow[i,j,:]
            dvector_map[i,j] = np.arccos(np.clip(np.dot(_vector, baseline_vector),-1,1))*(180.0/math.pi)
            '''
            if flow[i,j,0] == 0 and flow[i,j,1]==0:
                dvector_map[i,j] = 0.0
            else:
                dvector_map[i,j] = np.arccos(np.dot(_vector,baseline_vector))
                dvector_map[i,j] = np.arccos(np.clip(np.dot(_vector, baseline_vector),-1,1))
            '''
    return dvector_map

def magnitude_flow(flow,normalization=0):
    '''
    :param flow: flow element such as optical flow and social force model
    :return: magnitude value of each flow element
    '''
    _threshold = 0.2
    _width, _height, _depth = np.shape(flow)
    magnitude_map = np.sqrt(np.power(flow[:,:,0],2)+np.power(flow[:,:,1],2))
    if normalization==0:
        return magnitude_map
    elif normalization==1:
        for i in range(_width):
            for j in range(_height):
                if magnitude_map[i,j] < _threshold:
                    magnitude_map = 0.0
        return magnitude_map
    else:
        print 'normalization parameter have to 0 or 1, otherwise are errors\n'
        sys.exit()

def marked_image(img,abnormality_map,_stv_w):
    _w,_h,_td = np.shape(abnormality_map)
    _img = cv2.cvtColor(img,cv2.COLOR_GRAY2BGR)
    for i in range(_w):
        for j in range(_h):
            if abnormality_map[i,j]==0:
                continue
            else:
                cv2.rectangle(_img,(i*_stv_w,j*_stv_w),(i*_stv_w+_stv_w,j*_stv_w+_stv_w),(255,0,0),2)
    return _img

def feature_map_plot(featuremap):
    _width,_height,_depth = np.shape(featuremap)
    _x_axis = np.reshape(featuremap[:,:,0],(_width*_height,1))
    _y_axis = np.reshape(featuremap[:,:,1],(_width*_height,1))
    plt.plot(_x_axis,_y_axis,'ro')
    plt.xlabel('Motion speed')
    plt.ylabel('Motion pattern complexity')
    plt.title('Crowd motion information')
    plt.grid(True)
    plt.show()

def EuclideanDist(v1,v2):
    dist = np.linalg.norm(v1-v2)
    return dist



def Regional_analysis(set_feature_map,_ths):
    '''
    :param imgset: training image set (Initial N frame which contains only normal situation
    :param _w: scale of volume in x axis for spatio-temporal volume
    :param _h: scale of voume in y axis for spatio-temporal volume
    :param _t: temporal axis (time) for spatio-temporal volume
    :return: clustered region information
    feature map consist of magnitude of velocity and complexity of motion pattern of spatio-temporal frame
    '''
    _init = 1
    _threshold = _ths
    _w,_h,_d,_len = np.shape(set_feature_map)
    probability_map = np.zeros((_w,_h,2),dtype=float)
    class_map = np.zeros((_w,_h),dtype=int)
    codebook = np.zeros((100,2),dtype=float)
    _sizebook = np.ones((100,1),dtype=float)
    for i in range(_w):
        for j in range(_h):
            probability_map[i,j,0] = sum(set_feature_map[i,j,0,:])/_len# mean of magnitude element of each grid
            probability_map[i,j,1] = sum(set_feature_map[i,j,1,:])/_len# mean of entropy element of each grid

    #serial k-means classification
    _num_codebook = 0
    for i in range(_w):
        for j in range(_h):
            if _init==1:
                codebook[_num_codebook,:] = probability_map[i,j,:]
                _sizebook[_num_codebook] = 1
                class_map[i,j] = _num_codebook
                _num_codebook += 1
                _init = 0
            else:
                _temp = 100000.0 #sufficiently big number
                _temp_book_num = 0
                for k in range(_num_codebook):
                    _dist = EuclideanDist(codebook[k,:],probability_map[i,j,:])
                    if _dist < _temp:
                        _temp = _dist
                        _temp_book_num = k
                if _temp < _threshold:
                    codebook[_temp_book_num,:] = (codebook[_temp_book_num,:]*_sizebook[_temp_book_num]+probability_map[i,j,:])/(_sizebook[_temp_book_num]+1)
                    _sizebook[_temp_book_num] += 1
                    class_map[i,j] = _temp_book_num
                else:
                    codebook[_num_codebook,:] = probability_map[i,j,:]
                    class_map[i,j] = _num_codebook
                    _num_codebook += 1

    return codebook,class_map,_num_codebook,_sizebook[0:_num_codebook]

def Set_BOGs(_set_featuremap,_classmap,_sizeofclass,_numbog,_gw,_gh):
    _num_of_class,temp = np.shape(_sizeofclass)
    init = 0;
    _img_width, _img_height,_img_depth,_temporal_len,_num_clip = np.shape(_set_featuremap)
    _sizeof_raw_feature = _sizeofclass*_num_clip
    _temp = _sizeof_raw_feature.max()
    _feature_space = np.zeros((_num_of_class,_temp,_gw,_gh,_img_depth,_temporal_len),dtype=float)

    for i in range(_num_of_class):
        for j in range(_num_clip):
            for k in range(_img_width/_gw):
                for t in range(_img_height/_gh):
                    if _classmap[k,t]==i:
                        _feature_space[i,init,:,:,:,:] = _set_featuremap[k*_gw:k*_gw+_gw,t*_gh:t*_gh+_gh,:,:,j]
                        init += 1
            init = 0

    _set_codebook = np.zeros((_num_of_class,_numbog,_gw,_gh,_img_depth,_temporal_len),dtype=float)
    for i in range(_num_of_class):
        #k-means for construction of BOG
        _set_codebook[i,:,:,:,:,:] = K_means_custom(_feature_space[i,0:_sizeof_raw_feature[i],:,:,:,:],_numbog,100)
    return _set_codebook


def K_means_custom(_data,_numbog,_iter):
    _size,_gw,_gh,_img_depth,_temporal_len = np.shape(_data)
    _centroid = _data[0:_numbog,:,:,:,:]
    _clustered_set = np.zeros((_numbog,_gw,_gh,_img_depth,_temporal_len),dtype=float)
    _cluster_mag = np.zeros((_numbog),dtype=float)
    _init = 0
    _step = 0
    if _size <= _numbog:
        print 'Sample space is smaller then number of visual word that required'
        _centroid = _data
        return _centroid
    else:
        while _step != _iter:
            _temp_dist = 10000
            _temp_class = 0
            for i in range(_size):
                for j in range(_numbog):
                    _dist = EuclideanDist(_centroid[j],_data[i])
                    if _dist <= _temp_dist:
                        _temp_dist = _dist
                        _temp_class = j
                _clustered_set[_temp_class,:,:,:,:] += _data[i,:,:,:,:]
                _cluster_mag[_temp_class] += 1
            for t in range(_numbog):
                _centroid[t,:,:,:,:] = _clustered_set[t,:,:,:,:]/_cluster_mag[t]
            _clustered_set = np.zeros((_numbog,_gw,_gh,_img_depth,_temporal_len),dtype=float)
            _cluster_mag = np.zeros((_numbog),dtype=float)
            _step += 1
        return _centroid
'''
def Set_BOGs(_set_featuremap,_gw,_gh,_gd,_num_bog,_classmap,_sizebook):
    _code_len,_temp = np.shape(_sizebook)
    _scale = np.zeros((_code_len,1),dtype=int)
    _width,_height,_depth,_v_depth,_size = np.shape(_set_featuremap)
    _new_classbook = _sizebook
    _max_space = _new_classbook.max()
    _new_classbook = _new_classbook*_max_space
    _feature_space = np.zeros((_code_len,_max_space,_gw,_gh,_gd,_v_depth),dtype=float)
    _codebook = np.zeros((_numcode,_num_bog,_gw,_gh,_gd),dtype=float)

    #Extracting spatio-tempora feature
    for k in range(_size):
        for i in range(_width/_gw):
            for j in range(_height/_gh):
                _feature_space[_classmap[i,j],_scale[_classmap[i,j]],:,:,:,:] = _set_featuremap[i*_gw:i*_gw+_gw,j*_gh:j*_gh+_gh,:,:,k]
                _scale[_classmap[i,j]] += 1


    #Construction of Bag of word
    #k-means
    for t in range(_code_len):
        _codebook[t] = K_means_custom(_feature_space[t])
    return _codebook
'''

def detect(_data,_codebook,_threshold=0.2):
    _numbog,_gw,_gh,_img_depth,_temporal_len = np.shape(_codebook)
    _dist = 0
    for i in range(_numbog):
        _dist += EuclideanDist(_data,_codebook[i])

    if _dist > _threshold:
        return 1 # abnormal
    else:
        return 0


def AbnorEvDet(_set_flow,_set_codebook,_classmap):
    _width,_height,_img_depth,_temp_len = np.shape(_set_flow)
    _num_of_class,_numbog,_gw,_gh,_img_depth,_temporal_len = np.shape(_set_codebook)
    _abnormality_map = np.zeros((_width/_gw,_height/_gh,1),dtype=int)
    abnormality = 0
    for i in range(_width/_gw):
        for j in range(_height/_gh):
            abnormality = detect(_set_flow[i*_gw:i*_gw+_gw,j*_gh:j*_gh+_gh,:,:],_set_codebook[_classmap[i,j]],_threshold=15)
            if abnormality == 0:
                #print 'normal'
                _abnormality_map[i,j] = 0
            else:
                #print 'abnormal'
                _abnormality_map[i,j] = 1
    return _abnormality_map



if __name__ == '__main__':



    #Parameter for experiment
    _stv_w  = 20
    _stv_h = 20
    _stv_l = 1 #temp
    _mapping_threshold = 0.3
    _num_centroid = 1
    l_volume = 10

    print _message
    #cap = video.create_capture('/home/schmizt/Workspace/SF_abnormaly/DB/Normal_Abnormal_Crowd/Normal Crowds/CRW116.mov')
    cap = video.create_capture('/home/schmizt/Workspace/SF_abnormaly/UNMdata.avi')
    ret, prev = cap.read()
    prevgray = cv2.cvtColor(prev, cv2.COLOR_BGR2GRAY)
    show_hsv = False
    show_glitch = False
    cur_glitch = prev.copy()
    width, height, length = np.shape(prev)

    #dataset for the proposed algorithm
    set_mag_map = np.zeros((width, height,10),dtype=float)
    set_dvec_map = np.zeros((width,height,10),dtype=float)
    _temp_smm = np.zeros((width, height,5),dtype=float)
    _temp_dbm = np.zeros((width,height,5),dtype=float)

    _set_flow = np.zeros((width, height,2,10),dtype=float)
    _temp_set_flow = np.zeros((width, height,5),dtype=float)

    _set_feature_map = np.zeros((width/_stv_w,height/_stv_h,2,_stv_l),dtype=float)
    _raw_featuremap = np.zeros((width,height,2,l_volume,_stv_l),dtype=float)
    ####################################

    prev_flow = np.zeros((width,height,length-1),dtype=float)
    volume_of = np.zeros((width,height,length-1,l_volume),dtype=float)
    _num_fm = 0
    _learning = True
    _detection  = False
    _minit = 10
    _num_of_frame = 0
    init = 0

    while _learning:
        ret, img = cap.read()
        _num_of_frame += 1
        if ret==0:
            break
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        flow = cv2.calcOpticalFlowFarneback(prevgray, gray, 0.5, 3, 10, 3, 5, 1.2, 0) #extract optical flow
        prevgray = gray

        # show magnitude map of optical flow
        if init<10: #overlapped 5 frame to time axis
            set_mag_map[:,:,init] = magnitude_flow(flow)
            set_dvec_map[:,:,init] = dvector_flow(flow)
            _set_flow[:,:,:,init] = flow
            init += 1
        else:
            if _minit==10:
                #_feature_map = _spatio_feature_map(set_mag_map,set_dvec_map,_stv_w,_stv_h) #Extract spatial feature
                _feature_map = _spatiotemporal_feature_map(set_mag_map,set_dvec_map,_stv_w,_stv_h,l_volume) # modifying spatio-temporal featureat\_num_fm +
                _set_feature_map[:,:,:,_num_fm] = _feature_map[:,:,:]
                _raw_featuremap[:,:,:,:,_num_fm] = _set_flow
                _num_fm += 1
                print '%d is collected\n'%(_num_fm)
                #feature_map_plot(_feature_map)
                set_mag_map[:,:,0:5] = set_mag_map[:,:,5:10]
                set_dvec_map[:,:,0:5] = set_dvec_map[:,:,5:10]
                _set_flow[:,:,:,0:5] = _set_flow[:,:,:,5:10]
                _minit = 5
            else:
                set_mag_map[:,:,_minit] = magnitude_flow(flow)
                set_dvec_map[:,:,_minit] = dvector_flow(flow)
                _set_flow[:,:,:,_minit] = flow
                _minit += 1

            if _num_fm == _stv_l:
                print 'Regional Analysis process' # Regional anlaysis
                _centroid,_classmap,_numcode,_sizebook = Regional_analysis(_set_feature_map,_mapping_threshold)
                print 'Regional Analysis Done\n'

                #cv2.imshow('temp_image',draw_ra_result(gray,_stv_w,_classmap))
                cv2.imwrite('map.jpg',draw_ra_result(gray,_stv_w,_classmap))

                #learing is in progress
                print 'Construction normal model in each region'
                _set_codebook = Set_BOGs(_raw_featuremap,_classmap,_sizebook,_num_centroid,_stv_w,_stv_h)
                print 'Construction is Done'
                _learning = False
                _detection = True
        ch = 0xFF & cv2.waitKey(5)
        if ch == 27:
            print 'process fin'
            break

    _num_fm = 0
    _minit = 10
    _num_of_frame = 0
    init = 0
    print 'Detection mode'
    while _detection:
        ret, img = cap.read()
        _num_of_frame += 1
        if ret==0:
            break
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        flow = cv2.calcOpticalFlowFarneback(prevgray, gray, 0.5, 3, 10, 3, 5, 1.2, 0) #extract optical flow
        prevgray = gray

        # show magnitude map of optical flow
        if init<10: #overlapped 5 frame to time axis
            _set_flow[:,:,:,init] = flow
            init += 1
        else:
            if _minit==10:
                _abnormality_map = AbnorEvDet(_set_flow,_set_codebook,_classmap)
                cv2.imshow('Abnormal Event Detection',marked_image(gray,_abnormality_map,_stv_w))
                _num_fm += 1
                _set_flow[:,:,:,0:5] = _set_flow[:,:,:,5:10]
                _minit = 5
            else:
                _set_flow[:,:,:,_minit] = flow
                _minit += 1

        #Detection module
        ch = 0xFF & cv2.waitKey(5)
        if ch == 27:
            print 'process fin'
            break
    cv2.destroyAllWindows()
