import random
import pylab
import numpy as np
import cv2
from scipy.ndimage import interpolation
import video
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.pyplot as plt

help_message = '''
USAGE: opt_flow.py [<video_source>]

Keys:
 1 - toggle HSV flow visualization
 2 - toggle glitch

Hyperparameter for computing social force
- relaxation parameter
-
'''
'''
def draw_hsv(flow):
    h, w = flow.shape[:2]
    fx, fy = flow[:,:,0], flow[:,:,1]
    ang = np.arctan2(fy, fx) + np.pi
    v = np.sqrt(fx*fx+fy*fy)
    hsv = np.zeros((h, w, 3), np.uint8)
    hsv[...,0] = ang*(180/np.pi/2)
    hsv[...,1] = 255
    hsv[...,2] = np.minimum(v*4, 255)
    bgr = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
    return bgr
'''
def inter_force(img,flow,flowset,lent,rlx=1.0,panix=0.0):
    h, w = img.shape[:2]
    fx, fy = flow[:,:,0], flow[:,:,1]
    tempflow = flow
    #difflowx = fx - flowset[:,:,0,lent-1]
    #difflowy = fy - flowset[:,:,1,lent-1]
    flowsumx=+ flowset[:,:,0,0]
    flowsumy=+ flowset[:,:,1,0]
    for i in range(lent-1):
        flowsumx= flowsumx + flowset[:,:,0,i+1]
        flowsumy= flowsumy+ flowset[:,:,1,i+1]
    avgflowx = flowsumx/lent
    avgflowy = flowsumy/lent
    intFflowx = (1/rlx)*((1-panix)*fx+panix*avgflowx-avgflowx)#-difflowx
    intFflowy = (1/rlx)*((1-panix)*fy+panix*avgflowy-avgflowy)#-difflowy
    tempflow[:,:,0] = intFflowx
    tempflow[:,:,1] = intFflowy
    return tempflow

def draw_flow(img, flow, step=12):
    h, w = img.shape[:2]
    y, x = np.mgrid[step/2:h:step, step/2:w:step].reshape(2,-1)
    fx, fy = flow[y,x].T
    lines = np.vstack([x, y, x+fx, y+fy]).T.reshape(-1, 2, 2)
    lines = np.int32(lines + 0.5) # value of optical flow
    vis = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    cv2.polylines(vis, lines, 0, (0, 255, 0))
    for (x1, y1), (x2, y2) in lines:
        cv2.circle(vis, (x1, y1), 1, (0, 255, 0), -1)
    return vis

def draw_inFandFlow(img,flow,flowset,lent = 10.0,rlx=1.0,panix=0.0,step=12):
    kernel = np.ones((10,10),np.float32)/25;
    h, w = img.shape[:2]
    y, x = np.mgrid[step/2:h:step, step/2:w:step].reshape(2,-1)
    #Computing Optical Flow
    fx, fy = flow[y,x].T
    lines = np.vstack([x, y, x+fx, y+fy]).T.reshape(-1, 2, 2)
    lines = np.int32(lines + 0.5) # value of optical flow
    #computing interaction Force
    Interflow = inter_force(img,flow,flowset,lent,rlx,panix)
    intFx, intFy = Interflow[y,x].T
    temp_intFx = np.square(Interflow[:,:,0])
    temp_intFy = np.square(Interflow[:,:,1])
    forceflow_vis = np.sqrt(temp_intFx+temp_intFy)
    #Computing Interaction Force - another flow
    #xx = 0.0
    #yy = 0.0
    #for i in range(lent):
    #   xx,yy =+ flowset[y,x,:,i].T
    #xx= xx/lent
    #yy=yy/lent #average of optical flows
    #difx, dify = flow[y,x].T - flowset[y,x,:,lent-1].T #difference of velocity for computing interaction force in social force

    #intFx = (1/rlx)*((1-panix)*fx+panix*xx-xx)-difx
    #intFy = (1/rlx)*((1-panix)*fy+panix*yy-yy)-dify
    lines_f = np.vstack([x, y, x+intFx, y+intFy]).T.reshape(-1, 2, 2)
    lines_f = np.int32(lines_f + 0.5) # value of optical flow

    vis = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    cv2.polylines(vis, lines, 0, (0, 255, 0))#optical flow line
    cv2.polylines(vis, lines_f,0,(0,0,255))#interaction Forace line
    for (x1, y1), (x2, y2) in lines_f:
        cv2.circle(vis, (x1, y1), 1, (0, 0, 0), -1)
    forceflow_vis = cv2.filter2D(forceflow_vis,-1,kernel)
    return vis,forceflow_vis,intFx,intFy,Interflow

def draw_hsv(flow):
    h, w = flow.shape[:2]
    fx, fy = flow[:,:,0], flow[:,:,1]
    ang = np.arctan2(fy, fx) + np.pi
    v = np.sqrt(fx*fx+fy*fy)
    hsv = np.zeros((h, w, 3), np.uint8)
    hsv[...,0] = ang*(180/np.pi/2)
    hsv[...,1] = 255
    hsv[...,2] = np.minimum(v*4, 255)
    bgr = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
    return bgr

def draw_hsv_Foceflow(forceflow):
    return


def draw_hsv_Foceflow(img,flow,flowset,lent):
    h, w = flow.shape[:2]
    tempflow = inter_force(img,flow,flowset,lent)
    fx, fy  = tempflow[:,:,0],tempflow[:,:,1]
    ang = np.arctan2(fy, fx) + np.pi
    v = np.sqrt(fx*fx+fy*fy)
    hsv = np.zeros((h, w, 3), np.uint8)
    hsv[...,0] = ang*(180/np.pi/2)
    hsv[...,1] = 255
    hsv[...,2] = np.minimum(v*4, 255)
    bgr = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
    return bgr

def warp_flow(img, flow):
    h, w = flow.shape[:2]
    flow = -flow
    flow[:,:,0] += np.arange(w)
    flow[:,:,1] += np.arange(h)[:,np.newaxis]
    res = cv2.remap(img, flow, None, cv2.INTER_LINEAR)
    return res

def extract_visualword(of_set,numclip,numvw,width,height):
    vw_count = 0;
    windowsize = 5
    coord = np.zeros((numclip,numvw,2),dtype=float)
    for i in range(numclip):
        while(vw_count!=numvw):
            temp_x = random.randrange(0+windowsize,height-windowsize)
            temp_y = random.randrange(0+windowsize,width-windowsize)
            if(of_set[i,temp_y,temp_x,0] > 0 and of_set[i,temp_y,temp_x,1] > 0):
                coord[i,vw_count,0] = temp_x
                coord[i,vw_count,1] = temp_y
                vw_count = vw_count +1
            else:
                continue;
        vw_count = 0;
    return coord


if __name__ == '__main__':
    import sys
    print help_message
    try: fn = sys.argv[1]
    except: fn = 0
    emphasize_parameter = 3
    fig, ax = plt.subplots()
    lent = 10;
    segmentation = 0;
    temp_count = 0;

    #spefication for visual word (Bag of force)
    initial_normal_frame =100 #
    vw_length = 5 #size of volume
    vw_height = 5 #size of volume
    vw_interval = lent # size of volume
    num_of_clip = 10;
    num_of_vw = 30 #number of visual word
    bag_of_force = np.zeros((num_of_clip,num_of_vw,vw_length,vw_height,vw_interval),dtype=float)
    coord_bof = np.zeros((num_of_clip,num_of_vw,2),dtype=int) #peaked coordinate for visual word (x,y)

    cap = video.create_capture('/media/Database/Abnormal Event GIST/Abnormal_proto/9_1.avi')
    #cap = video.create_capture('D:\ICTR&D_project\SF_abnormaly\DB\Normal_Abnormal_Crowd\Normal Crowds\879-38_l.mov')
    ret, prev = cap.read()
    if prev==None:
        print 'Exit module'
        exit();


    prevgray = cv2.cvtColor(prev, cv2.COLOR_BGR2GRAY)
    show_hsv = False
    show_glitch = False
    show_ffhsv = False
    show_ff = False
    temp_tt = 0;
    cur_glitch = prev.copy()

    flowset = np.zeros((np.size(prev,0),np.size(prev,1),np.size(prev,2)-1,lent),dtype=float);
    int_flowset = np.zeros((np.size(prev,0),np.size(prev,1),np.size(prev,2)-1,lent),dtype=float);
    start = 0;
    flowsumX = 0;
    flowsumY = 0;
    ret, img = cap.read()
    width= np.size(img,0)
    height = np.size(img,1)
    num_of_frame = 0;
    temp_flowset= np.zeros((num_of_clip,np.size(prev,0),np.size(prev,1),np.size(prev,2)-1,lent),dtype=float);
    temp_of = np.zeros((num_of_clip,np.size(prev,0),np.size(prev,1),np.size(prev,2)-1),dtype=float);


    while True:
        num_of_frame = num_of_frame+1
        ret, img = cap.read()
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        flow = cv2.calcOpticalFlowFarneback(prevgray, gray, 0.5, 3, 15, 3, 5, 1.2, 0)
        flow = emphasize_parameter*flow #parameter setting for visualiation
        #cv2.imshow('Gaussian',flow[:,:,0])#temp result for flow imagization
        if start<lent:
            flowset[:,:,:,start] = flow;
            prevgray = gray
            vis,vis_ff,intFx,intFy,Interflow_temp =  draw_inFandFlow(gray,flow,flowset,lent)
            int_flowset[:,:,:,start] = Interflow_temp
            start = start+1;
            cv2.imshow('flow', vis)
            #cv2.imshow('force flow',vis_ff)
            #cv2.imshow('flow', draw_flow(gray, flow))
        else:
            if(start%10==0 and start <=100):
                #LDA learning phase  after then, detection abnormal situation
                temp_flowset[temp_count,:,:,:,:] = int_flowset[:,:,:] # temp_flowset = force flow set
                temp_of[temp_count,:,:,:] = flowset[:,:,:,0]
                temp_count = temp_count +1
            prevgray = gray
            vis,vis_ff,intFx,intFy,Interflow_temp =  draw_inFandFlow(gray,flow,flowset,lent)
            start = start+1
            cv2.imshow('flow',vis)
            #cv2.imshow('force flow',vis_ff)
            #cv2.imshow('flow', draw_flow(gray, flow)) #Because of optical flow has a noise by procedure using library(OpenCV), the Social Force can be computed with noise. In this version, this problem is caused.
            flowset[:,:,:,0:lent-2]=flowset[:,:,:,1:lent-1]
            flowset[:,:,:,lent-1] = flow
            int_flowset[:,:,:,0:lent-2]=int_flowset[:,:,:,1:lent-1]
            int_flowset[:,:,:,lent-1] = Interflow_temp
        ch = 0xFF & cv2.waitKey(5)
        if ch == 27:
            print 'process fin'
            break

    cv2.destroyAllWindows()
