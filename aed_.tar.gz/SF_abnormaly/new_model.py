__author__ = 'jongminyu'

#!/usr/bin/env python

import numpy as np
import cv2
import video
import sys
from matplotlib import pyplot as plt
import math
from sklearn.cluster import KMeans
from sklearn import datasets

_message = '''
Keys:
    Title.Abnormal event detection
    Dev by J.m.Yu @ GIST & Ph.D Candidate
    Dev at 2015
    'esc' : exit process
    volume length is 10
'''

def draw_flow(img, flow, step=16):
    h, w = img.shape[:2]
    y, x = np.mgrid[step/2:h:step, step/2:w:step].reshape(2,-1)
    fx, fy = flow[y,x].T
    lines = np.vstack([x, y, x+fx, y+fy]).T.reshape(-1, 2, 2)
    lines = np.int32(lines + 0.5)
    vis = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    cv2.polylines(vis, lines, 0, (0, 255, 0))
    for (x1, y1), (x2, y2) in lines:
        cv2.circle(vis, (x1, y1), 1, (0, 255, 0), -1)
    return vis

def draw_grid(img,_window_size=10):
    h, w = img.shape[:2]
    vis = show_grid(cv2.cvtColor(img,cv2.COLOR_GRAY2BGR),_window_size)
    return vis

def draw_sf_flow(img, flow, step=16):
    h, w = img.shape[:2]
    y, x = np.mgrid[step/2:h:step, step/2:w:step].reshape(2,-1)
    fx, fy = flow[y,x].T
    lines = np.vstack([x, y, x+fx, y+fy]).T.reshape(-1, 2, 2)
    lines = np.int32(lines + 0.5)
    vis = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    cv2.polylines(vis, lines, 0, (0, 0, 255))
    for (x1, y1), (x2, y2) in lines:
        cv2.circle(vis, (x1, y1), 1, (0, 0, 255), -1)
    return vis

def show_magnitude_map(title,magnitude_flow):
    if title=='Optical flow magnitude':
        p = plt.imshow(magnitude_flow, interpolation="gaussian")
    elif title=='Social force magnitude':
        p = plt.imshow(magnitude_flow, interpolation="gaussian")
    else:
        print '[error] title parameter only can process two input (Optical flow magnitude and Social force magnitude)\n'
        sys.exit()

def calcSocialForceMeharn(avg_of,current_of,previous_of):
    '''
    :param avg_of: average optical flow of spatio-temporal volume
    :param current_of: optical flow at current steps
    :param previous_of: optical flow at previous steps
    :return: actual force (social force model)
    '''
    tau = 2.0
    panic = 1.0
    _temp = (1-panic)*current_of-panic*avg_of-current_of
    actual_force = 2/tau*(_temp)-(current_of-previous_of)
    return actual_force


def calcHistogram(wflow,B=8):
    '''
    :param wflow: object flow in specific window
    :param B: hisgotram size
    :return: histogram of object flow
    '''
    _interval = 360/B
    _bins = range(0,360,_interval)
    _bins.append(360)
    _width,_height,_depth = np.shape(wflow)
    _result = np.reshape(wflow,(_width*_height*_depth))
    _flow_histogram = np.histogram(wflow,bins=_bins)
    return _flow_histogram


def calcEntropyfromHistogram(_histogram):
    '''
    :param flow: flow element such as optical flow and social force model
    :return: entropy map of flow elements
    '''
    _total_histogram = sum(_histogram[0])
    _entropy = 0.0
    _length = len(_histogram[0])
    for i in range(_length):
        if _histogram[0][i] == 0:
            continue
        else:
            _entropy += (-1.0)*(float(_histogram[0][i])/float(_total_histogram))*math.log((float(_histogram[0][i])/float(_total_histogram)),10)
    return _entropy

def avg_speed_in_grid(grid_mag_map):
    '''
    Compute average speed in each grid using magnitude map
    :param grid_mag_map: each window extracted from magnitude map
    :param g_w: width size of grid (window)
    :param g_h: height size of grid (Window)
    :return: average speed of each window
    '''
    _width,_height = np.shape(grid_mag_map)
    avg_speed = 0.0
    '''
    for i in range(_width):
        for j in range(_height):
            avg_speed += grid_mag_map[i,j]
    '''
    avg_speed = sum(sum(grid_mag_map))
    return avg_speed/(_width*_height)

def avg_speed_in_volume(volume_mag_map):
    '''
    :param volume_mag_map: spatio-temporal voluem of magnitude map (sequence of magnitude map)
    :return: average speed that is represented by optical flow of spatio-temporal volume
    '''
    _width,_height,_length = np.shape(volume_mag_map)
    avg_speed = 0.0
    for l in range(_length):
        avg_speed += avg_speed_in_grid(volume_mag_map[:,:,l])
    return avg_speed/_length


def of_histogram_show(flow):
    return 0

def sf_histogram_show():
    return 0

def segmentation_by_of():
    return 0

def segmentation_by_sf():
    return 0


def speed_map():
    return 0

def _spatio_feature_map(set_mag_map,set_dvec_map):
    '''
    Version 1 spatial feature map
    :param set_mag_map:
    :param set_dvec_map:
    :return:
    '''
    _grid_width = 20
    _grid_height = 20
    _width, _height,_length = np.shape(set_mag_map)
    _feature_map = np.zeros((_width/_grid_height,_height/_grid_height,2),dtype=float)
    for i in range(_width/_grid_width):
        for j in range(_height/_grid_height):
            _feature_map[i,j,0] = avg_speed_in_volume(set_mag_map[i*10:i*10+10,j*10:j*10+10,:])
            _feature_map[i,j,1] = calcEntropyfromHistogram(calcHistogram(set_dvec_map[i*10:i*10+10,j*10:j*10+10,:],12))
    return _feature_map

def _spatiotemporal_feature_map(st_mag_map,st_dvec_map):# not work - will be modified
    '''
    version 1 spatio-temporal feature map
    We assume that temporal depth of input of this function is 10
    :param st_mag_map:
    :param st_dvec_map:
    :return:
    '''
    _volume_width = 20
    _volume_height = 20
    _volume_depth = 10
    _width, _height,_depth = np.shape(set_mag_map)
    _feature_map = np.zeros((_width/_volume_height,_height/_volume_height,2,_depth/_volume_depth),dtype=float)
    for i in range(_width/_volume_width):
        for j in range(_height/_volume_height):
            for k in range(_depth/_volume_depth):
                _feature_map[i,j,0,k] = avg_speed_in_volume(set_mag_map[i*_volume_width:i*_volume_width+_volume_width,j*_volume_height:j*_volume_height+_volume_height,k])
                _feature_map[i,j,1,k] = calcEntropyfromHistogram(calcHistogram(set_dvec_map[i*_volume_width:i*_volume_width+_volume_width,j*_volume_height:j*_volume_height+_volume_height,k],12))
    return _feature_map




def map_show(title,img,flow,count):
    '''
    :param title: window title
    :param img:original image
    :param flow: element flow
    :return:
    '''
    if title=='Optical flow':
        flow  *= 5 #emphasize optical flow for visualization
        cv2.imshow('Optical flow', draw_flow(img, flow))
        cv2.imwrite('./ofoutput/'+str(count)+'.tif',draw_flow(img, flow))
    elif title=='Social force flow':
        flow *= 3
        cv2.imshow('Social force flow',draw_sf_flow(img,flow))
    else:
        print '[error] : '+title+'is not mapping element'
        return 0

def unit_vector(vector):
    '''
    making unit vector from input (vector)
    :param vector: input vector
    :return: unit vector from input vector
    '''
    return vector/np.linalg.norm(vector)


def show_grid(img,_window_size=10):
    _width,_height,_depth = np.shape(img)
    for i in range(_width/_window_size):
        img[i*_window_size,:,:] = 0
    for j in range(_height/_window_size):
        img[:,j*_window_size,:] = 0
    return img


def dvector_flow(flow):
    '''
    :param flow: flow element such as optical flow and social force model
    :return: direction element (i.e. 30 degree)
    '''
    _width, _height, _depth = np.shape(flow)
    dvector_map = np.zeros((_width,_height),dtype=float)
    baseline_vector = [1.0,0.0]
    for i in range(_width):
        for j in range(_height):
            _vector =  unit_vector(flow[i,j,:])
            _temp = flow[i,j,:]
            dvector_map[i,j] = np.arccos(np.clip(np.dot(_vector, baseline_vector),-1,1))*(180.0/math.pi)
            '''
            if flow[i,j,0] == 0 and flow[i,j,1]==0:
                dvector_map[i,j] = 0.0
            else:
                dvector_map[i,j] = np.arccos(np.dot(_vector,baseline_vector))
                dvector_map[i,j] = np.arccos(np.clip(np.dot(_vector, baseline_vector),-1,1))
            '''
    return dvector_map

def magnitude_flow(flow,normalization=0):
    '''
    :param flow: flow element such as optical flow and social force model
    :return: magnitude value of each flow element
    '''
    _threshold = 0.2
    _width, _height, _depth = np.shape(flow)
    magnitude_map = np.sqrt(np.power(flow[:,:,0],2)+np.power(flow[:,:,1],2))
    if normalization==0:
        return magnitude_map
    elif normalization==1:
        for i in range(_width):
            for j in range(_height):
                if magnitude_map[i,j] < _threshold:
                    magnitude_map = 0.0
        return magnitude_map
    else:
        print 'normalization parameter have to 0 or 1, otherwise are errors\n'
        sys.exit()


def feature_map_plot(featuremap):
    _width,_height,_depth = np.shape(featuremap)
    _x_axis = np.reshape(featuremap[:,:,0],(_width*_height,1))
    _y_axis = np.reshape(featuremap[:,:,1],(_width*_height,1))
    plt.plot(_x_axis,_y_axis,'ro')
    plt.xlabel('Motion speed')
    plt.ylabel('Motion pattern complexity')
    plt.title('Crowd motion information')
    plt.grid(True)
    plt.show()

def EuclideanDist(v1,v2):
    dist = np.linalg.norm(v1-v2)
    return dist


def Regional_analysis(set_feature_map):
    '''
    :param imgset: training image set (Initial N frame which contains only normal situation
    :param _w: scale of volume in x axis for spatio-temporal volume
    :param _h: scale of voume in y axis for spatio-temporal volume
    :param _t: temporal axis (time) for spatio-temporal volume
    :return: clustered region information
    feature map consist of magnitude of velocity and complexity of motion pattern of spatio-temporal frame
    '''
    _init = 1
    _threshold = 0.1
    _w,_h,_d,_len = np.shape(set_feature_map)
    probability_map = np.zeros((_w,_h,2),dtype=float)
    class_map = np.zeros((_w,_h),dtype=int)
    codebook = np.zeros((100,2),dtype=float)
    for i in range(_w):
        for j in range(_h):
            probability_map[i,j,0] = sum(set_feature_map[i,j,0,:])/_len# mean of magnitude element of each grid
            probability_map[i,j,1] = sum(set_feature_map[i,j,1,:])/_len# mean of entropy element of each grid

    #serial k-means classification
    _num_codebook = 0
    for i in range(_w):
        for j in range(_h):
            if _init==1:
                codebook[_num_codebook,:] = probability_map[i,j,:]
                class_map[i,j] = _num_codebook
                _num_codebook += 1
            else:
                _temp = 100000.0 #sufficiently big number
                _temp_book_num = 0
                for k in range(_num_codebook):
                    _dist = EuclideanDist(codebook[k,:],probability_map[i,j,:])
                    if _dist < _temp:
                        _temp = _dist
                        _temp_book_num = k
                if _temp < _threshold:
                    codebook[_temp_book_num,:] = (codebook[_temp_book_num,:]+probability_map[i,j,:])/2
                    class_map[i,j] = _temp_book_num
                else:
                    codebook[_num_codebook,:] = probability_map[i,j,:]
                    class_map[i,j] = _num_codebook
                    _num_codebook += 1

    return codebook,class_map,_num_codebook




def AbnorEvDet():
    return 0



if __name__ == '__main__':
    l_volume = 10
    init = 0
    print _message
    #cap = video.create_capture('/home/schmizt/Workspace/SF_abnormaly/DB/Normal_Abnormal_Crowd/Normal Crowds/CRW116.mov')
    cap = video.create_capture('/media/Database/Abnormal Event GIST/Abnormal_proto/9_1.avi')
    ret, prev = cap.read()
    prevgray = cv2.cvtColor(prev, cv2.COLOR_BGR2GRAY)
    show_hsv = False
    show_glitch = False
    cur_glitch = prev.copy()
    width, height, length = np.shape(prev)

    #dataset for the proposed algorithm
    set_mag_map = np.zeros((width, height,10),dtype=float)
    set_dvec_map = np.zeros((width,height,10),dtype=float)
    ####################################

    prev_flow = np.zeros((width,height,length-1),dtype=float)
    volume_of = np.zeros((width,height,length-1,l_volume),dtype=float)
    _c_volume = 0
    _framecout = 0
    while True:
        ret, img = cap.read()
        if ret==0:
            break
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        flow = cv2.calcOpticalFlowFarneback(prevgray, gray, 0.5, 3, 10, 3, 5, 1.2, 0) #extract optical flow
        prevgray = gray

        map_show('Optical flow',gray,flow,_framecout)
        _framecout += 1
        #show image with grid - temp code
        #cv2.imshow('temp_image',draw_grid(gray,20))


        ch = 0xFF & cv2.waitKey(5)
        if ch == 27:
            print 'process fin'
            break
    cv2.destroyAllWindows()
