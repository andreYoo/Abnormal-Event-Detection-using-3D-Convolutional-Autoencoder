__author__ = 'schmizt'
import cv2
import os


_experiment_path = '/media/Database/VISAPP_TESTDB/'
_GIST_path = 'GIST_DB/'
_UCSDPed_path = 'UCSDPed/'
_UCSDPed1_train_path = 'UCSDped1/Train/'
_UCSDPed1_test_path = 'UCSDped1/Test/'
_UCSDPed2_train_path = 'UCSDped2/Train/'
_UCSDPed2_test_path = 'UCSDped2/Test/'


def f_name_transfer(start):
    _path ='/media/Database/VISAPP_TESTDB/UMNdataset/Scene2'
    _ftype = '.tif'
    _outtype = '.tif'
    _temp = start
    _fcount = 0
    _fpath = _path+'/'+str(_temp)+_ftype
    _output_path = _path+'/'+str(_fcount)+_ftype
    while True:
        img = cv2.imread(_fpath)
        cv2.imwrite(_output_path,img)
        _fcount += 1
        _temp += 1
        _fpath = _path+'/'+str(_temp)+_ftype
        _output_path = _path+'/temp/'+str(_fcount)+_outtype
        print _temp
        if _temp == 5595:
            break
    return 0


if __name__ == '__main__':
    f_name_transfer(1452)
    print 'process is done'
