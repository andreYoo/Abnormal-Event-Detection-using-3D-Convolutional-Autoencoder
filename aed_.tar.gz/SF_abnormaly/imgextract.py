__author__ = 'schmizt'
import cv2
import video
import os

_experiment_path = '/media/Database/VISAPP_TESTDB/'
_GIST_path = 'GIST_DB/'
_UCSDPed_path = 'UCSDPed/'
_UCSDPed1_train_path = 'UCSDPed1/Train/'
_UCSDPed1_test_path = 'UCSDPed1/Test/'
_UCSDPed2_train_path = 'UCSDPed2/Train/'
_UCSDPed2_test_path = 'UCSDPed2/Test/'

def Get_filelist(_dir_path):
    res = []
    for root, dirs, files in os.walk(_dir_path):
        rootpath = os.path.join(os.path.abspath(_dir_path), root)
        for file in files:
            filepath = os.path.join(rootpath, file)
            if os.path.isdir(filepath):
                continue
            else:
                res.append(filepath)
    return res




if __name__ == '__main__':
    _temp = 0
    _path_GISTdataset = '/media/Database/VISAPP_TESTDB/UMNdataset/temp'
    _file_list = Get_filelist(_path_GISTdataset)
    for _fpath in _file_list:
        _frame = 0
        _dir_path = _fpath.split('.')
        if not os.path.exists(_dir_path[0]):
            os.makedirs(_dir_path[0])
        cap = video.create_capture(_fpath)

        ret, prev = cap.read()
        if prev==None:
            print 'Exit module'
            exit();
        while True:
            ret, img = cap.read()
            if ret==False:
                print str(_file_list)+"[Done]"
                break
            _file_name = _dir_path[0]+'/'+str(_frame)+'.tif'
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            cv2.imwrite(_file_name,gray)
            cv2.putText(gray,str(_frame),(10,30),cv2.FONT_HERSHEY_COMPLEX_SMALL,1,(255,0,0))
            cv2.imshow('Image',gray)
            _frame += 1
            ch = 0xFF & cv2.waitKey(5)
            if ch == 27:
                break
        cv2.destroyAllWindows()
        _temp += 1
        if _temp ==1:
            break;