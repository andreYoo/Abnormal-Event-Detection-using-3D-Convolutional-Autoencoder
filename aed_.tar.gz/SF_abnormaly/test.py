import matplotlib.pyplot as plt
import numpy as np
import math
import numpy as np

print np.arccos(np.clip(np.dot([1,0], [0,1]),-1,1))*180/math.pi
